Generic Cromwell backend code.
