#!/bin/bash

set -e
java $JAVA_OPTS -jar /cromwell/cromwell.jar server
