package cromwell.services

package object metadata {
  type QueryParameters = Seq[QueryParameter]
}
