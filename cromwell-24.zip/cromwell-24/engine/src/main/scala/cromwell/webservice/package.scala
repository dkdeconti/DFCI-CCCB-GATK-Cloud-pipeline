package cromwell

package object webservice {
  type QueryParameters = Seq[QueryParameter]
}
